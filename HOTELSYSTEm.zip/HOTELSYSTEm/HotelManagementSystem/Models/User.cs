using System.ComponentModel.DataAnnotations;

namespace HotelManagementSystem.Models;
public class User
{
    [Key]
    public int UserId { get; set; } // Primary Key
    public string Username { get; set; } = null!;
    public string Password { get; set; } = null!;
    public string Role { get; set; } = null!;
    
}
