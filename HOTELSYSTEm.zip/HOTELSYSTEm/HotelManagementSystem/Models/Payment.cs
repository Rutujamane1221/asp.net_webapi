using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HotelManagementSystem.Models
{
    public class Payment
    {
        [Key]
        public int PaymentId { get; set; } 
        
    
        [ForeignKey("Reservation")]
        public int? ReservationId { get; set; }
        [ForeignKey("Staff")]
        public int? EmployeeId { get; set; }

        public decimal TotalAmount { get; set; } 
        
        public DateTime PaymentTime { get; set; } 

        public string CreditCardDetails { get; set; } = null!; 
        public required string PaymentMethod { get; set; }
         public Staff? Staff { get; set; }
        public Reservation? Reservation { get; set; } 
        public DateTime PaymentDate { get; internal set; }
    }
}
