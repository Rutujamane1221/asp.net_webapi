// Models/Bill.cs

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HotelManagementSystem.Models
{
    public class Bill
    {
        [Key]
        public int BillId { get; set; } 
        [Required]
        public string BillingNo { get; set; } = null!; 

        public DateTime StayDates { get; set; } 

        public decimal TotalPrice { get; set; } 

        public decimal Taxes { get; set; } 

        public decimal Services { get; set; } 

        // Foreign Key to Reservation
        [ForeignKey("Reservation")]
        public int ReservationId { get; set; } 

        
        public virtual required Reservation Reservation { get; set; } 
    }
}
