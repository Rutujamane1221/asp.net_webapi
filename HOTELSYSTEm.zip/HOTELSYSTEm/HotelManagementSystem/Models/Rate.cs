// Models/Rate.cs
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HotelManagementSystem.Models
{
    public class Rate
    {
        [Key]
        public int RateId { get; set; }  

        [Required]
        public DateTime CheckInDate { get; set; }  

        [Required]
        public DateTime CheckOutDate { get; set; } 

        [Required]
        public required string DayOfWeek { get; set; }  

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal TotalCharge { get; set; } 

       public DateTime? DeletedAt { get; set; }  
    }
}
