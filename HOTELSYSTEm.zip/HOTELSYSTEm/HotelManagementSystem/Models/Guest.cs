using System.ComponentModel.DataAnnotations;

namespace HotelManagementSystem.Models
{
    public class Guest
    {
        [Key]
        public int GuestId { get; set; } // Primary Key

        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = null!;

        [Required]
        [EmailAddress]
        [MaxLength(255)]
        public string Email { get; set; } = null!;

        [Required]
        [MaxLength(10)]
        public string Gender { get; set; } = null!; // Example: "Male", "Female", "Other"

        [Required]
        [MaxLength(500)]
        public string Address { get; set; } = null!;

        [Required]
        [Phone]
        [MaxLength(15)]
        public string PhoneNumber { get; set; } = null!;

        [Required]
        [MaxLength(50)]
        public string MemberCode { get; set; } = null!;
    }
}
