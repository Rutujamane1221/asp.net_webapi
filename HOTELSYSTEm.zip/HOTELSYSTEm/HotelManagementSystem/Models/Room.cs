// Models/Room.cs
using System.ComponentModel.DataAnnotations;

namespace HotelManagementSystem.Models
{
    public class Room
    {   
        [Key]
        public int RoomId { get; set; } 
        public string RoomNumber { get; set; }= null!; 
        public string RoomType { get; set; }= null!;       
         public int Capacity { get; set; }
        public double PricePerNight { get; set; } 
        public bool IsAvailable { get; set; } 
    }
}
