using System;
using System.Collections;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace HotelManagementSystem.Models;

public partial class HotelContext(DbContextOptions<HotelContext> options) : DbContext(options)
{
    
    public virtual required DbSet<User> Users { get; set; }
    public virtual required DbSet<Staff> Staffs { get; set; }

    public required DbSet<Guest> Guests { get; set; } 
    public virtual required DbSet<Room> Rooms { get; set; }
    public virtual required DbSet<Reservation> Reservations{ get; set; }
     public virtual required DbSet<Payment> Payments{ get; set; }
     public virtual required DbSet<Bill> Bills{ get; set; }
    public virtual required DbSet<Rate> Rates{ get; set; }
    public virtual required DbSet<Inventory> Inventories{ get; set; }
    

    protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            
            modelBuilder.Entity<Room>()
                .Property(r => r.PricePerNight)
                .HasColumnType("decimal(18,2)"); 
        }

    
}

