using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HotelManagementSystem.Models
{
    public class Reservation
    {
        [Key]
        public int ReservationId { get; set; }  // Primary Key

        
        [ForeignKey("Guest")]
        public int GuestId { get; set; } 

       
        [ForeignKey("Room")]
        public int RoomId { get; set; }  

        public DateTime CheckInDate { get; set; }
        public DateTime CheckOutDate { get; set; }

        public int NumAdults { get; set; }
        public int NumChildren { get; set; }
        public string Status { get; set; } = "Pending"; 
        
        public int NumNights 
        {
            get
            {
                return (CheckOutDate - CheckInDate).Days;
            }
        }

        // Navigation Properties
        public required Guest Guest { get; set; }  
         public required Room Room { get; set; }    

        
    }
}
