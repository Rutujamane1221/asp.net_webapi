// Models/Inventory.cs

using System.ComponentModel.DataAnnotations;

namespace HotelManagementSystem.Models
{
    public class Inventory
    { 
        [Key]
        public int ItemId { get; set; }         
        public required string ItemName { get; set; }     
        public required string Category { get; set; }    
        public int Quantity { get; set; }      
        public decimal Price { get; set; }       
    }
}
