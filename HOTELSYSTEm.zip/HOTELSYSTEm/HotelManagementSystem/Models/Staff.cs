using System.ComponentModel.DataAnnotations;

namespace HotelManagementSystem.Models
{
    public class Staff
    {
        [Key]  
        public int employee_Id { get; set; }

        [Required]
        public string employee_name { get; set; } = null!;

        public int age { get; set; }

        public string? address { get; set; } 
        

        public string? Salary { get; set; }  
        

        public string designation { get; set; } = null!;

        [EmailAddress]
        public string email { get; set; } = null!;

        [RegularExpression(@"^[A-Za-z]{2}\d{3}$", ErrorMessage = "Invalid code format")]
        public string code { get; set; } = null!;
    }
}
