// Services/BillService.cs
using HotelManagementSystem.DTO;
using HotelManagementSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelManagementSystem.Service
{
    

    public class BillService : IBillService
    {
        private readonly HotelContext _context;

        public BillService(HotelContext context)
        {
            _context = context;
        }

        // Issue Bill based on the reservation
        public async Task<BillDTO> IssueBillAsync(BillDTO billDTO)
        {
            var reservation = await _context.Reservations
                .Include(r => r.Guest)
                .Include(r => r.Room)
                .FirstOrDefaultAsync(r => r.ReservationId == billDTO.ReservationId);

            if (reservation == null)
                throw new Exception("Reservation not found.");

            // Calculate total price, taxes, and services
            decimal totalPrice = (decimal)(reservation.NumAdults * reservation.Room.PricePerNight * reservation.NumNights);
            decimal taxes = totalPrice * 0.1m; // Assuming a 10% tax rate
            decimal services = 50m; 
            var bill = new Bill
            {
                BillingNo = GenerateBillingNo(),
                StayDates = reservation.CheckInDate,
                TotalPrice = totalPrice + taxes + services,
                Taxes = taxes,
                Services = services,
                ReservationId = reservation.ReservationId,
                Reservation = reservation // Navigation property
            };

            _context.Bills.Add(bill);
            await _context.SaveChangesAsync();

           
            return new BillDTO
            {
                BillingNo = bill.BillingNo,
                StayDates = bill.StayDates,
                TotalPrice = bill.TotalPrice,
                Taxes = bill.Taxes,
                Services = bill.Services,
                ReservationId = bill.ReservationId
            };
        }

        private string GenerateBillingNo()
        {
            
            return "BILL" + DateTime.Now.Ticks.ToString();
        }
    }
}

