using HotelManagementSystem.DTO;

namespace HotelManagementSystem.Service
{
    public interface IBillService
    {
        Task<BillDTO> IssueBillAsync(BillDTO billDTO);
    }
}
