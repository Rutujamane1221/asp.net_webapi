using HotelManagementSystem.Models;
using HotelManagementSystem.Models.DTOs;
using Microsoft.EntityFrameworkCore;  // Ensure this is at the top
using System.Threading.Tasks;

namespace HotelManagementSystem.Services
{
    public class GuestService : IGuestService
    {
        private readonly HotelContext _context;

        public GuestService(HotelContext context)
        {
            _context = context;
        }

        public async Task<Guest> AddGuestAsync(GuestDto guestDto)
        {
            
            if (!IsValidPhoneNumber(guestDto.PhoneNumber))
                throw new ArgumentException("Invalid phone number format.");

            if (!IsValidEmail(guestDto.Email))
                throw new ArgumentException("Invalid email format.");

            
            var existingGuest = await _context.Guests
                .FirstOrDefaultAsync(g => g.Name == guestDto.Name);  

            if (existingGuest != null)
                throw new ArgumentException("A guest with this name already exists.");

            
            var guest = new Guest
            {
                Name = guestDto.Name,
                Email = guestDto.Email,
                Gender = guestDto.Gender,
                Address = guestDto.Address,
                PhoneNumber = guestDto.PhoneNumber,
                MemberCode = guestDto.MemberCode
            };

            
            _context.Guests.Add(guest);
            await _context.SaveChangesAsync();

            return guest;
        }

        public async Task<Guest> UpdateGuestAsync(string name, GuestDto guestDto)
        {
            
            if (!IsValidPhoneNumber(guestDto.PhoneNumber))
                throw new ArgumentException("Invalid phone number format.");

            if (!IsValidEmail(guestDto.Email))
                throw new ArgumentException("Invalid email format.");

            
            var existingGuest = await _context.Guests
                .FirstOrDefaultAsync(g => g.Name == name);

            if (existingGuest == null)
                throw new ArgumentException("Guest not found.");

            
            existingGuest.Address = guestDto.Address;
            existingGuest.MemberCode = guestDto.MemberCode;

           
            _context.Guests.Update(existingGuest);
            await _context.SaveChangesAsync();

            return existingGuest;
        }

        public async Task<Guest?> GetGuestByNameAsync(string name)
        {
            
            return await _context.Guests
                .FirstOrDefaultAsync(g => g.Name == name); 
        }

        
        private bool IsValidPhoneNumber(string phoneNumber)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(phoneNumber, @"^\+?\d{10,15}$");
        }

      
        private bool IsValidEmail(string email)
        {
            return System.Text.RegularExpressions.Regex.IsMatch(email, @"^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$");
        }

        

       
    }
}
