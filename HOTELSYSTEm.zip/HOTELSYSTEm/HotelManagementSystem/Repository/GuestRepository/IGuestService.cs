using HotelManagementSystem.Models;
using HotelManagementSystem.Models.DTOs;

namespace HotelManagementSystem.Services
{
    public interface IGuestService
    {
        Task<Guest> AddGuestAsync(GuestDto guestDto);
        Task<Guest> UpdateGuestAsync(string name, GuestDto guestDto);
        Task<Guest?> GetGuestByNameAsync(string name); // Add this line
    }
}
