using HotelManagementSystem.DTO;
using HotelManagementSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelManagementSystem.Service
{
    public class ReportService : IReportService
    {
        private readonly HotelContext _context;

        public ReportService(HotelContext context)
        {
            _context = context;
        }

       
        public async Task<List<StaffPaymentReportDTO>> GetStaffPaymentsReportAsync()
        {
            var staffPayments = await _context.Payments
                .Where(p => p.EmployeeId.HasValue) 
                .Include(p => p.Staff)
                .GroupBy(p => p.EmployeeId)
                .Select(g => new StaffPaymentReportDTO
                {
                    EmployeeId = g.Key.Value,
                    EmployeeName = g.First().Staff.employee_name, 
                    TotalSalaryPaid = g.Sum(p => p.TotalAmount), 
                    PaymentTime = g.Max(p => p.PaymentTime)      
                }).ToListAsync();

            return staffPayments;
        }

        // Method to get Income Report
        public async Task<List<IncomeReportDTO>> GetIncomeReportAsync()
        {
            var incomeReports = await _context.Payments
                .Where(p => p.ReservationId.HasValue)  
                .Include(p => p.Reservation)
                .GroupBy(p => p.ReservationId)
                .Select(g => new IncomeReportDTO
                {
                    ReservationId = g.Key.Value,
                    TotalAmount = g.Sum(p => p.TotalAmount),   
                    PaymentTime = g.Max(p => p.PaymentTime),  
                    PaymentMethod = g.First().PaymentMethod    
                }).ToListAsync();

            return incomeReports;
        }
    }
}
