using HotelManagementSystem.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HotelManagementSystem.Service
{
    public interface IReportService
    {
        // Method to get Staff Payment Report
        Task<List<StaffPaymentReportDTO>> GetStaffPaymentsReportAsync();

        // Method to get Income Report
        Task<List<IncomeReportDTO>> GetIncomeReportAsync();
    }
}
