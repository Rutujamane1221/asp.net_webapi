
using HotelManagementSystem.DTO;
using HotelManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using BCrypt.Net;
using System.Security.Claims;
using System.Threading.Tasks;

namespace HotelManagementSystem.Service
{
    public class UserService : IUserService
    {
        private readonly HotelContext _context;
        private readonly JwtService _jwtService;

        public UserService(HotelContext context, JwtService jwtService)
        {
            _context = context;
            _jwtService = jwtService;

           
            CreateDefaultOwner();
        }

        private void CreateDefaultOwner()
        {
            var existingOwner = _context.Users.FirstOrDefault(u => u.Username == "owner");

            if (existingOwner == null)
            {
                var owner = new User
                {
                    Username = "owner", 
                    Password = BCrypt.Net.BCrypt.HashPassword("Pass@123"), 
                    Role = "Owner" 
                };

                _context.Users.Add(owner);
                _context.SaveChangesAsync().Wait();
            }
        }

        public async Task<UserDTO> RegisterUserAsync(UserDTO userDTO, string loggedInRole)
        {
    // Step 1: Only the "Owner" can register new users.
            if (loggedInRole != "Owner")
            {
             throw new UnauthorizedAccessException("Only Owner can register new users.");
           }

    // Step 2: Check if the user already exists.
           var existingUser = await _context.Users
           .FirstOrDefaultAsync(u => u.Username == userDTO.Username);

            if (existingUser != null)
           {
             throw new InvalidOperationException("User already exists.");
           }

    // Step 3: Validate the password.
          if (!IsPasswordValid(userDTO.Password))
          {
           throw new InvalidOperationException("Password does not meet the required criteria.");
          }  

    // Step 4: Hash the password and save the new user.
          var user = new User
          {
              Username = userDTO.Username,
              Password = BCrypt.Net.BCrypt.HashPassword(userDTO.Password),
              Role = userDTO.Role
          };

           _context.Users.Add(user);
           await _context.SaveChangesAsync();

    // Step 5: Return the UserDTO.
        return new UserDTO
           {
              Username = user.Username,
              Role = user.Role
           };
       }

        private bool IsPasswordValid(string password)
        {
    // Password validation rules using regex.
            var passwordPattern = new System.Text.RegularExpressions.Regex(
             @"^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,}$");

            return passwordPattern.IsMatch(password);
        }


       
        public async Task<string> LoginUserAsync(string username, string password)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Username == username);

            if (user == null || !BCrypt.Net.BCrypt.Verify(password, user.Password))
            {
                throw new UnauthorizedAccessException("Invalid username or password.");
            }

            var token = _jwtService.GenerateJwtToken(user.Username, user.Role);
            return token;
        }

     
        public async Task<string> LoginOwnerAsync(string username, string password)
        {
            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Username == username && u.Role == "Owner");

            if (user == null || !BCrypt.Net.BCrypt.Verify(password, user.Password))
            {
                throw new UnauthorizedAccessException("Invalid owner username or password.");
            }

            var token = _jwtService.GenerateJwtToken(user.Username, user.Role);
            return token;
        }

        
        public async Task<UserDTO> UpdateUserPasswordAsync(string username, string newPassword, string loggedInRole)
        {
            if (loggedInRole != "Owner")
            {
                throw new UnauthorizedAccessException("Only Owner can update user passwords.");
            }

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Username == username);

            if (user == null)
            {
                throw new KeyNotFoundException("User not found.");
            }

            user.Password = BCrypt.Net.BCrypt.HashPassword(newPassword);
            await _context.SaveChangesAsync();

            return new UserDTO
            {
                Username = user.Username,
                Role = user.Role
            };
        }

       
        public async Task DeleteUserAsync(string username, string loggedInRole)
        {
            if (loggedInRole != "Owner")
            {
                throw new UnauthorizedAccessException("Only Owner can delete users.");
            }

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.Username == username);

            if (user == null)
            {
                throw new KeyNotFoundException("User not found.");
            }

            _context.Users.Remove(user);
            await _context.SaveChangesAsync();
        }

        
        public async Task<UserDTO> GetUserByUsernameAsync(string username, string loggedInRole)
        {
            if (loggedInRole == "Owner")
            {
                var user = await _context.Users
                    .FirstOrDefaultAsync(u => u.Username == username);

                if (user == null)
                {
                    throw new KeyNotFoundException("User not found.");
                }

                return new UserDTO
                {
                    Username = user.Username,
                    Role = user.Role
                };
            }

            if (loggedInRole == "Manager" || loggedInRole == "Receptionist")
            {
                var user = await _context.Users
                    .FirstOrDefaultAsync(u => u.Username == username);

                if (user == null || user.Username != username)
                {
                    throw new KeyNotFoundException("User not found or mismatch.");
                }

                return new UserDTO
                {
                    Username = user.Username,
                    Role = user.Role
                };
            }

            throw new UnauthorizedAccessException("Invalid role.");
        }

        public void Logout(string username)
        {
            throw new NotImplementedException();
        }


        //     public void Logout(string username)
        // {

        //     Console.WriteLine($"{username} logged out successfully.");


        // }
    }
}
