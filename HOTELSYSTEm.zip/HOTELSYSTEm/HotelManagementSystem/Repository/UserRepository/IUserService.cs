using HotelManagementSystem.DTO;
using System.Threading.Tasks;

namespace HotelManagementSystem.Service
{
    public interface IUserService
    {
    
        Task<string> LoginUserAsync(string username, string password);

        
        Task<string> LoginOwnerAsync(string username, string password);

       
        Task<UserDTO> RegisterUserAsync(UserDTO userDTO, string loggedInRole);

      
        Task<UserDTO> UpdateUserPasswordAsync(string username, string newPassword, string loggedInRole);

       
        Task DeleteUserAsync(string username, string loggedInRole);

       
        Task<UserDTO> GetUserByUsernameAsync(string username, string loggedInRole);
         void Logout(string username); 
    }
}
