using HotelManagementSystem.DTO;
using HotelManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace HotelManagementSystem.Service
{
    public class RoomService : IRoomService
    {
        private readonly HotelContext _context;

        public RoomService(HotelContext context)
        {
            _context = context;
        }

      
        public async Task<RoomDTO> AddRoomAsync(RoomDTO roomDTO)
        {
            var room = new Room
            {
                RoomNumber = roomDTO.RoomNumber,
                RoomType = roomDTO.RoomType,
                Capacity = roomDTO.Capacity,
                PricePerNight = roomDTO.PricePerNight,
                IsAvailable = roomDTO.IsAvailable
            };

            _context.Rooms.Add(room);
            await _context.SaveChangesAsync();

        
            return new RoomDTO
            {
                RoomNumber = room.RoomNumber,
                RoomType = room.RoomType,
                Capacity = room.Capacity,
                PricePerNight = room.PricePerNight,
                IsAvailable = room.IsAvailable
            };
        }

        
        public async Task<RoomDTO> UpdateRoomAsync(string roomNumber, RoomDTO roomDTO)
        {
            var room = await _context.Rooms.FirstOrDefaultAsync(r => r.RoomNumber == roomNumber);

            if (room == null)
            {
                throw new ArgumentException("Room not found.");
            }

         
            room.PricePerNight = roomDTO.PricePerNight;
            room.IsAvailable = roomDTO.IsAvailable;

            await _context.SaveChangesAsync();

       
            return new RoomDTO
            {
                RoomNumber = room.RoomNumber,
                RoomType = room.RoomType,
                Capacity = room.Capacity,
                PricePerNight = room.PricePerNight,
                IsAvailable = room.IsAvailable
            };
        }

      
        public async Task DeleteRoomAsync(string roomNumber)
        {
            var room = await _context.Rooms.FirstOrDefaultAsync(r => r.RoomNumber == roomNumber);

            if (room == null)
            {
                throw new ArgumentException("Room not found.");
            }

            _context.Rooms.Remove(room);
            await _context.SaveChangesAsync();
        }

  
        public async Task<RoomDTO> SearchRoomAsync(string roomNumber)
        {
            var room = await _context.Rooms.FirstOrDefaultAsync(r => r.RoomNumber == roomNumber);

            if (room == null)
            {
                throw new ArgumentException("Room not found.");
            }

            return new RoomDTO
            {
                RoomNumber = room.RoomNumber,
                RoomType = room.RoomType,
                Capacity = room.Capacity,
                PricePerNight = room.PricePerNight,
                IsAvailable = room.IsAvailable
            };
        }
    }
}
