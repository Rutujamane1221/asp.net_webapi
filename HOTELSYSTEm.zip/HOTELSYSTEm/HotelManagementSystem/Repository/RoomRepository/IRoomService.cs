using HotelManagementSystem.DTO;
using System.Threading.Tasks;

namespace HotelManagementSystem.Service
{
    public interface IRoomService
    {
       
        Task<RoomDTO> AddRoomAsync(RoomDTO roomDTO);

        Task<RoomDTO> UpdateRoomAsync(string roomNumber, RoomDTO roomDTO);

      
        Task DeleteRoomAsync(string roomNumber);

     
        Task<RoomDTO> SearchRoomAsync(string roomNumber);
    }
}
