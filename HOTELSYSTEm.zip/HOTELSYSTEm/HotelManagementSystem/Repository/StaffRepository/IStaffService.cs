using HotelManagementSystem.DTO;
using System.Threading.Tasks;

namespace HotelManagementSystem.Service
{
    public interface IStaffService
    {
        Task<StaffDTO> AddStaffAsync(StaffDTO staffDTO);
        Task<StaffDTO> UpdateStaffAsync(string employeeName, StaffDTO staffDTO);
        Task DeleteStaffAsync(string employeeName);
        Task<StaffDTO> GetStaffByNameAsync(string employeeName);
    }
}
