// // StaffService.cs
using HotelManagementSystem.DTO;
using HotelManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace HotelManagementSystem.Service
{
    public class StaffService : IStaffService
    {
        private readonly HotelContext _context;

        public StaffService(HotelContext context)
        {
            _context = context;
        }

        // Add new staff
        public async Task<StaffDTO> AddStaffAsync(StaffDTO staffDTO)
        {
            var staff = new Staff
            {
                employee_name = staffDTO.employee_name,
                age = staffDTO.age,
                address = staffDTO.address,
                Salary = staffDTO.Salary,
                designation = staffDTO.designation,
                email = staffDTO.email,
                code = staffDTO.code
            };

            _context.Staffs.Add(staff);
            await _context.SaveChangesAsync();

            return new StaffDTO
            {
                employee_name = staff.employee_name,
                age = staff.age,
                address = staff.address,
                Salary = staff.Salary,
                designation = staff.designation,
                email = staff.email,
                code = staff.code
            };
        }

        
        public async Task<StaffDTO> UpdateStaffAsync(string employeeName, StaffDTO staffDTO)
        {
            var staff = await _context.Staffs
                .FirstOrDefaultAsync(s => EF.Functions.Collate(s.employee_name, "SQL_Latin1_General_CP1_CI_AS") == employeeName);

            if (staff == null)
            {
                throw new KeyNotFoundException($"Staff member with name '{employeeName}' not found.");
            }

            if (!string.IsNullOrEmpty(staffDTO.Salary))  
            {
                staff.Salary = staffDTO.Salary;
            }

            if (!string.IsNullOrEmpty(staffDTO.address)) 
            {
                staff.address = staffDTO.address;
            }

            if (!string.IsNullOrEmpty(staffDTO.designation))  
            {
                staff.designation = staffDTO.designation;
            }

            await _context.SaveChangesAsync();

            // Return updated staff details as DTO
            return new StaffDTO
            {
                employee_name = staff.employee_name,
                age = staff.age,
                address = staff.address,
                Salary = staff.Salary,
                designation = staff.designation,
                email = staff.email,
                code = staff.code
            };
        }

    


        public async Task<StaffDTO> GetStaffByNameAsync(string employeeName)
        {
            var staff = await _context.Staffs
                .FirstOrDefaultAsync(s => EF.Functions.Collate(s.employee_name, "SQL_Latin1_General_CP1_CI_AS") == employeeName);

            if (staff == null)
            {
                throw new KeyNotFoundException($"Staff member with name '{employeeName}' not found.");
            }

            return new StaffDTO
            {
                employee_name = staff.employee_name,
                age = staff.age,
                address = staff.address,
                Salary = staff.Salary,
                designation = staff.designation,
                email = staff.email,
                code = staff.code
            };
        }

        public Task DeleteStaffAsync(string employeeName)
        {
            throw new NotImplementedException();
        }
    }
}
