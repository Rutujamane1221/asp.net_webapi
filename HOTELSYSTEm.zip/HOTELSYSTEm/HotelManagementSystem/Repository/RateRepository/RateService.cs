using System;
using System.Linq;
using System.Threading.Tasks;
using HotelManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace HotelManagementSystem.Services
{
    public interface IRateService
    {
        Task<Rate> AddRateAsync(RateDto rateDto);
        Task<Rate?> GetRateByIdAsync(int rateId);
    }

    public class RateService : IRateService
    {
        private readonly HotelContext _context;

   
        private readonly List<string> _validDaysOfWeek = new List<string>
        {
            "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"
        };

        public RateService(HotelContext context)
        {
            _context = context;
        }

      
        public async Task<Rate> AddRateAsync(RateDto rateDto)
        {
            
            if (rateDto.CheckOutDate <= rateDto.CheckInDate)
            {
                throw new ArgumentException("Check-out date cannot be earlier than check-in date.");
            }

        
            if (!IsValidDayOfWeek(rateDto.DayOfWeek))
            {
                throw new ArgumentException("Invalid day of the week. Please use a valid day (e.g., Monday, Tuesday, etc.).");
            }

           
            var existingRate = await _context.Rates
                .Where(r => r.CheckInDate == rateDto.CheckInDate && r.CheckOutDate == rateDto.CheckOutDate && r.DayOfWeek == rateDto.DayOfWeek)
                .FirstOrDefaultAsync();

            if (existingRate != null)
            {
                throw new ArgumentException("A rate already exists for the specified date range and day.");
            }

            
            var rate = new Rate
            {
                CheckInDate = rateDto.CheckInDate,
                CheckOutDate = rateDto.CheckOutDate,
                DayOfWeek = rateDto.DayOfWeek,
                TotalCharge = rateDto.TotalCharge
            };

          
            _context.Rates.Add(rate);
            await _context.SaveChangesAsync();

            return rate;
        }

      
        public async Task<Rate?> GetRateByIdAsync(int rateId)
        {
            return await _context.Rates
                .FirstOrDefaultAsync(r => r.RateId == rateId);
        }

       
        private bool IsValidDayOfWeek(string dayOfWeek)
        {
            return _validDaysOfWeek.Contains(dayOfWeek, StringComparer.OrdinalIgnoreCase);
        }
    }
}
