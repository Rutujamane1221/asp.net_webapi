
using System;
using System.Linq;
using System.Threading.Tasks;
using HotelManagementSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelManagementSystem.Services
{
    public class InventoryService : IInventoryService
    {
        private readonly HotelContext _context;

        public InventoryService(HotelContext context)
        {
            _context = context;
        }

      
        public async Task<bool> AddInventoryItemAsync(InventoryDTO inventoryDto)
        {
            
            var existingItem = await _context.Inventories
                                              .FirstOrDefaultAsync(i => i.ItemName == inventoryDto.ItemName);
            if (existingItem != null)
                return false; // Item already exists

          
            var inventoryItem = new Inventory
            {
                ItemName = inventoryDto.ItemName,
                Category = inventoryDto.Category,
                Quantity = (int)inventoryDto.Quantity,  // Nullable, so it can be null or a value
                Price = (decimal)inventoryDto.Price,
                  
            };

            
            _context.Inventories.Add(inventoryItem);
            await _context.SaveChangesAsync();
            return true;
        }
        
        

         public async Task<bool> EditInventoryItemAsync(string itemName, InventoryDTO inventoryDto)
        {
    
                  var existingItem = await _context.Inventories
                                      .FirstOrDefaultAsync(i => i.ItemName == itemName);

    
                if (existingItem == null)
                return false;

  
               Console.WriteLine($"DTO - Price: {inventoryDto.Price}, Quantity: {inventoryDto.Quantity}, Category: {inventoryDto.Category}");

  

              if (inventoryDto.Price.HasValue)
          {
                existingItem.Price = inventoryDto.Price.Value;
                Console.WriteLine($"Updated Price: {existingItem.Price}");
          }

  
            if (!string.IsNullOrEmpty(inventoryDto.Category))
            {
                existingItem.Category = inventoryDto.Category;
               Console.WriteLine($"Updated Category: {existingItem.Category}");
            }

    
            if (inventoryDto.Quantity.HasValue)
           {
               existingItem.Quantity = inventoryDto.Quantity.Value;
              Console.WriteLine($"Updated Quantity: {existingItem.Quantity}");
           }

    
    
            _context.Inventories.Update(existingItem);
            await _context.SaveChangesAsync();

           return true;
       }


       
        public async Task<bool> DeleteInventoryItemAsync(string itemName)
        {
            
            var existingItem = await _context.Inventories
                                              .FirstOrDefaultAsync(i => i.ItemName == itemName);

          
            if (existingItem == null)
                return false;

           
            _context.Inventories.Remove(existingItem);
            await _context.SaveChangesAsync();

            return true;
        }
    }
}

