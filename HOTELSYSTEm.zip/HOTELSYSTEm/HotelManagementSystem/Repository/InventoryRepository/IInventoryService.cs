using System.Threading.Tasks;
using HotelManagementSystem.Models;

namespace HotelManagementSystem.Services
{
    public interface IInventoryService
    {
        Task<bool> AddInventoryItemAsync(InventoryDTO inventoryDto);
        Task<bool> EditInventoryItemAsync(string itemName, InventoryDTO inventoryDto);
        Task<bool> DeleteInventoryItemAsync(string itemName);
    }
}
