


using HotelManagementSystem.DTO;
using HotelManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;

namespace HotelManagementSystem.Service
{
    public class PaymentService : IPaymentService
    {
        private readonly HotelContext _context;

        public PaymentService(HotelContext context)
        {
            _context = context;
        }

        
        public async Task<StaffPaymentDTO> AddStaffPaymentAsync(StaffPaymentDTO staffPaymentDTO)
        {
           
            if (staffPaymentDTO.StaffId == 0)
            {
                throw new Exception("StaffId must be provided for staff payment.");
            }

           
            var staff = await _context.Staffs
                .FirstOrDefaultAsync(s => s.employee_Id == staffPaymentDTO.StaffId);

            if (staff == null)
            {
                throw new Exception("Staff member not found.");
            }

            
            var payment = new Payment
            {
                EmployeeId = staffPaymentDTO.StaffId,
                Staff = staff, 
                TotalAmount = staffPaymentDTO.Amount,
                PaymentMethod = staffPaymentDTO.PaymentMethod,
                CreditCardDetails = staffPaymentDTO.CreditCardDetails,
                PaymentTime = staffPaymentDTO.PaymentTime,
                PaymentDate = staffPaymentDTO.PaymentDate
            };

           
            _context.Payments.Add(payment);
            await _context.SaveChangesAsync();

            
            return new StaffPaymentDTO
            {
                StaffId = (int)payment.EmployeeId,
                Amount = payment.TotalAmount,
                PaymentMethod = payment.PaymentMethod,
                CreditCardDetails = payment.CreditCardDetails,
                PaymentTime = payment.PaymentTime,
                PaymentDate = payment.PaymentDate
            };
        }

        public async Task<ReservationPaymentDTO> AddReservationPaymentAsync(ReservationPaymentDTO reservationPaymentDTO)
        {
           
            if (reservationPaymentDTO.ReservationId == 0)
            {
                throw new Exception("ReservationId must be provided for reservation payment.");
            }

           
            var reservation = await _context.Reservations
                .FirstOrDefaultAsync(r => r.ReservationId == reservationPaymentDTO.ReservationId);

            if (reservation == null)
            {
                throw new Exception("Reservation not found.");
            }

            
            var payment = new Payment
            {
                ReservationId = reservationPaymentDTO.ReservationId,
                Reservation = reservation, 
                TotalAmount = reservationPaymentDTO.Amount,
                PaymentMethod = reservationPaymentDTO.PaymentMethod,
                CreditCardDetails = reservationPaymentDTO.CreditCardDetails,
                PaymentTime = reservationPaymentDTO.PaymentTime,
                PaymentDate = reservationPaymentDTO.PaymentDate
            };

          
            _context.Payments.Add(payment);
            await _context.SaveChangesAsync();

         
            return new ReservationPaymentDTO
            {
                ReservationId = (int)payment.ReservationId,
                Amount = payment.TotalAmount,
                PaymentMethod = payment.PaymentMethod,
                CreditCardDetails = payment.CreditCardDetails,
                PaymentTime = payment.PaymentTime,
                PaymentDate = payment.PaymentDate
            };
        }

        
    }
}
