
using HotelManagementSystem.DTO;
using System.Threading.Tasks;

namespace HotelManagementSystem.Service
{
    public interface IPaymentService
    {
        Task<StaffPaymentDTO> AddStaffPaymentAsync(StaffPaymentDTO staffPaymentDTO);

        Task<ReservationPaymentDTO> AddReservationPaymentAsync(ReservationPaymentDTO reservationPaymentDTO);
    }
}
