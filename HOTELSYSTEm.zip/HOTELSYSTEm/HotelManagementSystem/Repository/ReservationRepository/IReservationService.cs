using HotelManagementSystem.DTO;

namespace HotelManagementSystem.Service
{
    public interface IReservationService
    {
        Task<ReservationDTO> MakeReservationAsync(ReservationDTO reservationDTO);
        
    }

    
}
