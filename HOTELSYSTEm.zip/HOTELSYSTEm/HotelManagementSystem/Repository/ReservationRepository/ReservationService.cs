// using HotelManagementSystem.DTO;

using HotelManagementSystem.DTO;
using HotelManagementSystem.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;
using HotelManagementSystem.Services; 

namespace HotelManagementSystem.Service
{
    public class ReservationService : IReservationService
    {
        private readonly HotelContext _context;
        private readonly EmailService _emailService; 

        public ReservationService(HotelContext context, EmailService emailService)
        {
            _context = context;
            _emailService = emailService; 
        }

        public async Task<ReservationDTO> MakeReservationAsync(ReservationDTO reservationDTO)
        {
            
            if (reservationDTO.CheckInDate >= reservationDTO.CheckOutDate)
            {
                throw new ArgumentException("Check-in date must be earlier than check-out date.");
            }

            if (reservationDTO.Status != "Pending" && reservationDTO.Status != "Confirmed" && reservationDTO.Status != "Cancelled")
            {
                throw new ArgumentException("Invalid status. Allowed values are 'Pending', 'Confirmed', or 'Cancelled'.");
            }

           
            var guest = await _context.Guests.FindAsync(reservationDTO.GuestId);
            var room = await _context.Rooms.FindAsync(reservationDTO.RoomId);

            if (guest == null || room == null)
            {
                throw new ArgumentException("Invalid GuestId or RoomId.");
            }

          
            int numNights = (reservationDTO.CheckOutDate - reservationDTO.CheckInDate).Days;
            if (numNights < 1)
            {
                throw new ArgumentException("Reservation duration must be at least 1 night.");
            }

           
            var reservation = new Reservation
            {
                GuestId = reservationDTO.GuestId,
                RoomId = reservationDTO.RoomId,
                CheckInDate = reservationDTO.CheckInDate,
                CheckOutDate = reservationDTO.CheckOutDate,
                NumAdults = reservationDTO.NumAdults,
                NumChildren = reservationDTO.NumChildren,
                Status = reservationDTO.Status,
                Guest = guest,  
                Room = room,   
            };

          
            _context.Reservations.Add(reservation);
            await _context.SaveChangesAsync();

            var emailSubject = "Reservation Confirmation";
            var emailBody = $"Dear {guest.Name},<br><br>" +
                            $"Your reservation at our hotel has been successfully made.<br>" +
                            $"Reservation Details:<br>" +
                            $"Room: {room.RoomNumber}<br>" +
                            $"Check-in Date: {reservationDTO.CheckInDate.ToString("d")}<br>" +
                            $"Check-out Date: {reservationDTO.CheckOutDate.ToString("d")}<br>" +
                            $"Number of Adults: {reservationDTO.NumAdults}<br>" +
                            $"Number of Children: {reservationDTO.NumChildren}<br>" +
                            $"Status: {reservationDTO.Status}<br><br>" +
                            "We look forward to welcoming you to our hotel.<br><br>" +
                            "Best regards,<br>" +
                            "Hotel Management Team";

           
            await _emailService.SendEmailAsync(guest.Email, emailSubject, emailBody);

            return new ReservationDTO
            {
                GuestId = reservation.GuestId,
                RoomId = reservation.RoomId,
                CheckInDate = reservation.CheckInDate,
                CheckOutDate = reservation.CheckOutDate,
                NumAdults = reservation.NumAdults,
                NumChildren = reservation.NumChildren,
                Status = reservation.Status, // Return status
            };
        }
    }
}
