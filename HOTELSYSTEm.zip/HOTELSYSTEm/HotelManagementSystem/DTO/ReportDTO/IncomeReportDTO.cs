namespace HotelManagementSystem.DTO
{
    public class IncomeReportDTO
    {
        public int ReservationId { get; set; }       // Reservation ID
        public decimal TotalAmount { get; set; }     // Total income from the reservation
        public DateTime PaymentTime { get; set; }    // Payment time for the reservation
        public required string PaymentMethod { get; set; }    // Method of payment (e.g., Credit Card, Cash)
    }
}
