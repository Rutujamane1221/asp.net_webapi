namespace HotelManagementSystem.DTO
{
    public class StaffPaymentReportDTO
    {
        public int EmployeeId { get; set; }       // Staff ID
        public required string EmployeeName { get; set; }  // Staff Name
        public decimal TotalSalaryPaid { get; set; }  // Total salary paid
        public DateTime PaymentTime { get; set; }     // Payment date/time
    }
}
