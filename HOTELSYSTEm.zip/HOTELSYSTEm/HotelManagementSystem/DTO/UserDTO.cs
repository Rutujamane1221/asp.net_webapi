namespace HotelManagementSystem.DTO
{
    public class UserDTO
    {
        public string Username { get; set; }
        public string Password { get; set; } 
        public string Role { get; set; }

      
#pragma warning disable CS8618 
        public UserDTO() { }
#pragma warning restore CS8618 

       
        public UserDTO(string username, string password, string role)
        {
            Username = username;
            Password = password;
            Role = role;
        }
    }


    public class LoginDTO
    {
        public required string Username { get; set; }
        public required string Password { get; set; }
      
    }

    public class UpdatePasswordDTO
    {
        public required string Username { get; set; }
        public required string NewPassword { get; set; }
    }
}
