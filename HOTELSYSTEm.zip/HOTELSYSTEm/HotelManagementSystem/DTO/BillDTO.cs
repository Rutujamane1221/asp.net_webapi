// DTOs/BillDTO.cs
namespace HotelManagementSystem.DTO
{
    public class BillDTO
    {
        public string BillingNo { get; set; } = null!;
        public DateTime StayDates { get; set; }
        public decimal TotalPrice { get; set; }
        public decimal Taxes { get; set; }
        public decimal Services { get; set; }
        public int ReservationId { get; set; }
    }
}
