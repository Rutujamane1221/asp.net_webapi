using System;
using System.ComponentModel.DataAnnotations;

namespace HotelManagementSystem.DTO
{
    public class ReservationDTO
    {
        [Required]
        public int GuestId { get; set; } // Foreign Key to Guest

        [Required]
        public int RoomId { get; set; } // Foreign Key to Room

        [Required]
        [DataType(DataType.Date)]
        public DateTime CheckInDate { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime CheckOutDate { get; set; }

        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Number of adults must be at least 1.")]
        public int NumAdults { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Number of children cannot be negative.")]
        public int NumChildren { get; set; }

        [Required]
        [EnumDataType(typeof(ReservationStatus))]
        public string Status { get; set; } = "Pending"; // Status: Pending, Confirmed, Cancelled
    }

    public enum ReservationStatus
    {
        Pending = 1,
        Confirmed = 2,
        Cancelled = 3
    }
}
