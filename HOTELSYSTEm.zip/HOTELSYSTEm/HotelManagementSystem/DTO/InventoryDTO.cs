namespace HotelManagementSystem.Models
{
    public class InventoryDTO
    {
        public required string ItemName { get; set; }
        public required string Category { get; set; }
        public int? Quantity { get; set; }
        public decimal? Price { get; set; }
        
    }
}
