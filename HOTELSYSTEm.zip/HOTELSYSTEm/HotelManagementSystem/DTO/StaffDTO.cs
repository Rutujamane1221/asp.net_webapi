
// StaffDTO.cs
using System.ComponentModel.DataAnnotations;

namespace HotelManagementSystem.DTO
{
    public class StaffDTO
    {
        [Required]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Employee name must be between 3 to 100 characters.")]
        public string employee_name { get; set; } = null!;

        [Required]
        [Range(18, 100, ErrorMessage = "Age must be between 18 and 100.")]
        public int age { get; set; }

        public string? address { get; set; } 

        public string? Salary { get; set; }  

        [StringLength(50, ErrorMessage = "Designation should be a maximum of 50 characters.")]
        public string? designation { get; set; }

        [EmailAddress]
        public string? email { get; set; }

        [RegularExpression(@"^[A-Za-z]{2}\d{3}$", ErrorMessage = "Code must contain 2 alphabets followed by 3 digits.")]
        public string? code { get; set; }
    }
}
