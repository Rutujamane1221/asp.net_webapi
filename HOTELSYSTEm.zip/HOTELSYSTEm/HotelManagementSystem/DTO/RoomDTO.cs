namespace HotelManagementSystem.DTO
{
    public class RoomDTO
    {
        public string RoomNumber { get; set; } = null!; 
        public string RoomType { get; set; } = null!; 
        public int Capacity { get; set; } 
        public double PricePerNight { get; set; } 
        public bool IsAvailable { get; set; } 
    }
}
