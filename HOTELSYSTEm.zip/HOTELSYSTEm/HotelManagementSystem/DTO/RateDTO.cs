using System;
using System.ComponentModel.DataAnnotations;

namespace HotelManagementSystem.Models
{
    public class RateDto
    {
        [Required]
        public DateTime CheckInDate { get; set; }  

        [Required]
        public DateTime CheckOutDate { get; set; }  

        [Required]
        [RegularExpression(@"^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)$", 
            ErrorMessage = "Invalid day of the week. Please enter a valid day (e.g., Monday, Tuesday, etc.).")]
        public required string DayOfWeek { get; set; }  

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Total charge must be greater than 0.")]
        public decimal TotalCharge { get; set; }  
    }
}
