


namespace HotelManagementSystem.DTO
{
    public class StaffPaymentDTO
    {
        public int StaffId { get; set; }
        public decimal Amount { get; set; }

       public required string PaymentMethod { get; set; }

        
        public string? CreditCardDetails { get; set; }

        
        public DateTime PaymentTime { get; set; }

       
        public DateTime PaymentDate { get; set; }
    }

    
    public class ReservationPaymentDTO
    {
        public int ReservationId { get; set; }
        public decimal Amount { get; set; }

        
        public required string PaymentMethod { get; set; }

        
        public string? CreditCardDetails { get; set; }

        
        public DateTime PaymentTime { get; set; }

        
        public DateTime PaymentDate { get; set; }
    }
}
