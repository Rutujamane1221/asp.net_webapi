using Microsoft.AspNetCore.Mvc;
using HotelManagementSystem.Models;
using HotelManagementSystem.Services;
using Microsoft.AspNetCore.Authorization;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InventoryController : ControllerBase
    {
        private readonly IInventoryService _inventoryService;

        public InventoryController(IInventoryService inventoryService)
        {
            _inventoryService = inventoryService;
        }

        // Add a new inventory item
        [HttpPost]
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> AddInventoryItem([FromBody] InventoryDTO inventoryDto)
        {
            var success = await _inventoryService.AddInventoryItemAsync(inventoryDto);

            if (!success)
                return BadRequest("Item already exists or invalid data.");

            return Ok("Item added successfully.");
        }

        // Edit an existing inventory item
        [HttpPut("{itemName}")]
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> EditInventoryItem(string itemName, [FromBody] InventoryDTO inventoryDto)
        {
            var success = await _inventoryService.EditInventoryItemAsync(itemName, inventoryDto);

            if (!success)
                return NotFound("Item not found.");

            return Ok("Item updated successfully.");
        }

        // Delete an inventory item
        [HttpDelete("{itemName}")]
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> DeleteInventoryItem(string itemName)
        {
            var success = await _inventoryService.DeleteInventoryItemAsync(itemName);

            if (!success)
                return NotFound("Item not found.");

            return Ok("Item deleted successfully.");
        }
    }
}
