using HotelManagementSystem.DTO;
using HotelManagementSystem.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomsController : ControllerBase
    {
        private readonly IRoomService _roomService;

        public RoomsController(IRoomService roomService)
        {
            _roomService = roomService;
        }

        [HttpPost]
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> AddRoom([FromBody] RoomDTO roomDTO)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var addedRoom = await _roomService.AddRoomAsync(roomDTO);
            return CreatedAtAction(nameof(SearchRoom), new { roomNumber = addedRoom.RoomNumber }, addedRoom);
        }

        [HttpPut("{roomNumber}")]
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> UpdateRoom(string roomNumber, [FromBody] RoomDTO roomDTO)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var updatedRoom = await _roomService.UpdateRoomAsync(roomNumber, roomDTO);
            return Ok(updatedRoom);
        }

        [HttpDelete("{roomNumber}")]
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> DeleteRoom(string roomNumber)
        {
            await _roomService.DeleteRoomAsync(roomNumber);
            return NoContent();
        }

        [HttpGet("{roomNumber}")]
        [Authorize(Roles = "Receptionist")]

        public async Task<IActionResult> SearchRoom(string roomNumber)
        {
            var room = await _roomService.SearchRoomAsync(roomNumber);
            return Ok(room);
        }
    }
}
