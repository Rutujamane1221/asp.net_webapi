
using HotelManagementSystem.DTO;
using HotelManagementSystem.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        private readonly IPaymentService _paymentService;

        public PaymentController(IPaymentService paymentService)
        {
            _paymentService = paymentService;
        }

        // Endpoint for Staff Payment
        [HttpPost("addStaffPayment")]
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> AddStaffPayment([FromBody] StaffPaymentDTO staffPaymentDTO)
        {
            try
            {
                
                var payment = await _paymentService.AddStaffPaymentAsync(staffPaymentDTO);

                return Ok(payment); 
            }
            catch (Exception ex)
            {
                
                return BadRequest(ex.Message);
            }
        }

        // Endpoint for Reservation Payment
        [HttpPost("addReservationPayment")]
        [Authorize(Roles = "Receptionist")]
        public async Task<IActionResult> AddReservationPayment([FromBody] ReservationPaymentDTO reservationPaymentDTO)
        {
            try
            {
                
                var payment = await _paymentService.AddReservationPaymentAsync(reservationPaymentDTO);

                
                return Ok(payment); 
            }
            catch (Exception ex)
            {
                
                return BadRequest(ex.Message);
            }
        }
    }
}
