// Controllers/BillController.cs
using HotelManagementSystem.DTO;
using HotelManagementSystem.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BillController : ControllerBase
    {
        private readonly IBillService _billService;

        public BillController(IBillService billService)
        {
            _billService = billService;
        }

        // POST: api/bill
        [HttpPost]
        [Authorize(Roles = "Receptionist")]
        public async Task<IActionResult> IssueBill([FromBody] BillDTO billDTO)
        {
            if (billDTO == null)
                return BadRequest("Bill data is required.");

            try
            {
                var createdBill = await _billService.IssueBillAsync(billDTO);
                return CreatedAtAction(nameof(IssueBill), new { id = createdBill.BillingNo }, createdBill);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error occurred: {ex.Message}");
            }
        }
    }
}
