using HotelManagementSystem.DTO;
using HotelManagementSystem.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HotelManagementSystem.Controller
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        private readonly IReportService _reportService;

        public ReportController(IReportService reportService)
        {
            _reportService = reportService;
        }

        // Endpoint to get Staff Payment Report
        [HttpGet("staff-payment-report")]
        [Authorize(Roles = "Manager")]
        public async Task<ActionResult<List<StaffPaymentReportDTO>>> GetStaffPaymentsReport()
        {
            var staffPayments = await _reportService.GetStaffPaymentsReportAsync();
            return Ok(staffPayments);
        }

        // Endpoint to get Income Report
        [HttpGet("income-report")]
        [Authorize(Roles = "Manager,Receptionist")]
        public async Task<ActionResult<List<IncomeReportDTO>>> GetIncomeReport()
        {
            var incomeReports = await _reportService.GetIncomeReportAsync();
            return Ok(incomeReports);
        }
    }
}
