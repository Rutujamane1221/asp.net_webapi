using HotelManagementSystem.DTO;
using HotelManagementSystem.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReservationsController : ControllerBase
    {
        private readonly IReservationService _reservationService;

        public ReservationsController(IReservationService reservationService)
        {
            _reservationService = reservationService;
        }

        [HttpPost("make-reservation")]
        [Authorize(Roles = "Receptionist")]
        public async Task<IActionResult> MakeReservation([FromBody] ReservationDTO reservationDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); 
            }

            try
            {
               
                var reservation = await _reservationService.MakeReservationAsync(reservationDTO);
                return Ok(reservation);  
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);  
            }
        }
    }
}
