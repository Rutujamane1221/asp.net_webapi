using HotelManagementSystem.DTO;
using HotelManagementSystem.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StaffController : ControllerBase
    {
        private readonly IStaffService _staffService;

        public StaffController(IStaffService staffService)
        {
            _staffService = staffService;
        }

        // Add a new staff member
        [HttpPost]
        [Authorize(Roles = "Manager")]
        public async Task<ActionResult<StaffDTO>> AddStaffAsync([FromBody] StaffDTO staffDTO)
        {
            if (staffDTO == null)
            {
                return BadRequest("Staff data cannot be null.");
            }

            try
            {
                var addedStaff = await _staffService.AddStaffAsync(staffDTO);
                return CreatedAtAction(nameof(GetStaffByNameAsync), new { employeeName = addedStaff.employee_name }, addedStaff);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error adding staff: {ex.Message}");
            }
        }

        // Get staff by name
        [HttpGet("{employeeName}")]
        [Authorize(Roles = "Manager")]

        public async Task<ActionResult<StaffDTO>> GetStaffByNameAsync(string employeeName)
        {
            try
            {
                var staff = await _staffService.GetStaffByNameAsync(employeeName);
                return Ok(staff);
            }
            catch (KeyNotFoundException)
            {
                return NotFound($"Staff member with name '{employeeName}' not found.");
            }
            catch (Exception ex)
            {
                return BadRequest($"Error fetching staff: {ex.Message}");
            }
        }

        // Update staff (only Salary, Designation, and Address)
        [HttpPut("{employeeName}")]
        [Authorize(Roles = "Manager")]
        public async Task<ActionResult<StaffDTO>> UpdateStaffAsync(string employeeName, [FromBody] StaffDTO staffDTO)
        {
            if (staffDTO == null)
            {
                return BadRequest("Staff data cannot be null.");
            }

            try
            {
                var updatedStaff = await _staffService.UpdateStaffAsync(employeeName, staffDTO);
                return Ok(updatedStaff);
            }
            catch (KeyNotFoundException)
            {
                return NotFound($"Staff member with name '{employeeName}' not found.");
            }
            catch (Exception ex)
            {
                return BadRequest($"Error updating staff: {ex.Message}");
            }
        }

        // Delete staff by name
        [HttpDelete("{employeeName}")]
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> DeleteStaffAsync(string employeeName)
        {
            try
            {
                await _staffService.DeleteStaffAsync(employeeName);
                return NoContent();  // No content, successful deletion
            }
            catch (KeyNotFoundException)
            {
                return NotFound($"Staff member with name '{employeeName}' not found.");
            }
            catch (Exception ex)
            {
                return BadRequest($"Error deleting staff: {ex.Message}");
            }
        }
    }
}
