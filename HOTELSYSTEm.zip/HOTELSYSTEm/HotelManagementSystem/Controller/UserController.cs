

using HotelManagementSystem.DTO;
using HotelManagementSystem.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Threading.Tasks;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        #region Register
        [HttpPost("register")]
        [Authorize(Roles = "Owner")] 
        public async Task<IActionResult> RegisterUserAsync([FromBody] UserDTO userDTO)
        {
            try
            {
                var loggedInRole = User.FindFirst(ClaimTypes.Role)?.Value; 
#pragma warning disable CS8604 // Possible null reference argument.
                var result = await _userService.RegisterUserAsync(userDTO, loggedInRole);
#pragma warning restore CS8604 // Possible null reference argument.
                return Ok(result);
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
        #endregion

        #region Login
        [HttpPost("login")]
        public async Task<IActionResult> LoginUserAsync([FromBody] LoginDTO loginDTO)
        {
            try
            {
                var token = await _userService.LoginUserAsync(loginDTO.Username, loginDTO.Password);
                return Ok(new { token });
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(new { message = ex.Message });
            }
        }

        [HttpPost("loginOwner")]
        public async Task<IActionResult> LoginOwnerAsync([FromBody] LoginDTO loginDTO)
        {
            try
            {
                var token = await _userService.LoginOwnerAsync(loginDTO.Username, loginDTO.Password);
                return Ok(new { token });
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(new { message = ex.Message });
            }
        }
        #endregion

        #region Update User Password
//         [HttpPut("updatePassword")]
//         [Authorize(Roles = "Owner")]
//         public async Task<IActionResult> UpdateUserPasswordAsync([FromBody] UpdatePasswordDTO updatePasswordDTO)
//         {
//             try
//             {
//                 var loggedInRole = User.FindFirst(ClaimTypes.Role)?.Value;
// #pragma warning disable CS8604 
//                 var result = await _userService.UpdateUserPasswordAsync(updatePasswordDTO.Username, updatePasswordDTO.NewPassword, loggedInRole);
// #pragma warning restore CS8604 
//                 return Ok(result);
//             }
//             catch (UnauthorizedAccessException ex)
//             {
//                 return Unauthorized(new { message = ex.Message });
//             }
//             catch (KeyNotFoundException ex)
//             {
//                 return NotFound(new { message = ex.Message });
//             }
//         }

[HttpPut("updatePassword")]
[Authorize]  // Only authorize if the user is logged in
public async Task<IActionResult> UpdateUserPasswordAsync([FromBody] UpdatePasswordDTO updatePasswordDTO)
{
    try
    {
        // Make sure you are using the correct claim for username (inspect the claims or use the correct key)
        var loggedInUsername = User.FindFirst(ClaimTypes.Name)?.Value; // Or "UserData" or a custom claim key
        var loggedInRole = User.FindFirst(ClaimTypes.Role)?.Value;

        // Debugging info
        Console.WriteLine($"Logged-in Username: {loggedInUsername}");
        Console.WriteLine($"Request Username: {updatePasswordDTO.Username}");

        // Ensure the user is trying to update their own password
        if (loggedInUsername != updatePasswordDTO.Username)
        {
            return Unauthorized(new { message = "You can only update your own password." });
        }

        // Role-based authorization
        if (loggedInRole == "Owner" || loggedInRole == "Manager" || loggedInRole == "Receptionist")
        {
            var result = await _userService.UpdateUserPasswordAsync(updatePasswordDTO.Username, updatePasswordDTO.NewPassword, loggedInRole);
            return Ok(result);
        }
        else
        {
            return Forbid();
        }
    }
    catch (UnauthorizedAccessException ex)
    {
        return Unauthorized(new { message = ex.Message });
    }
    catch (KeyNotFoundException ex)
    {
        return NotFound(new { message = ex.Message });
    }
}

        #endregion

        #region Get User Details
        [HttpGet("getUser/{username}")]
        [Authorize]
        public async Task<IActionResult> GetUserByUsernameAsync(string username)
        {
            try
            {
                var loggedInRole = User.FindFirst(ClaimTypes.Role)?.Value;
#pragma warning disable CS8604 
                var userDTO = await _userService.GetUserByUsernameAsync(username, loggedInRole);
#pragma warning restore CS8604 
                return Ok(userDTO);
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(new { message = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }
        #endregion

//         [HttpPost("logout")]
//     [Authorize] 
//     public IActionResult Logout()
//     {
          
// #pragma warning disable CS8602 
//             var username = User.Identity.Name;
// #pragma warning restore CS8602 
        
// #pragma warning disable CS8604 
//             _userService.Logout(username);
// #pragma warning restore CS8604 
//             // Return a success response
//             return Ok(new { message = "You have logged out successfully." });
//     }
    }
}
