using HotelManagementSystem.Models;
using HotelManagementSystem.Models.DTOs;
using HotelManagementSystem.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GuestsController : ControllerBase
    {
        private readonly IGuestService _guestService;

        public GuestsController(IGuestService guestService)
        {
            _guestService = guestService;
        }

        // POST: api/guests/add
        [HttpPost("add")]
        [Authorize(Roles = "Receptionist")]
        public async Task<IActionResult> AddGuest([FromBody] GuestDto guestDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var guest = await _guestService.AddGuestAsync(guestDto);
                return CreatedAtAction(nameof(GetGuestByName), new { name = guest.Name }, guest);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "Internal Server Error", Details = ex.Message });
            }
        }

        // PUT: api/guests/update
        [HttpPut("update/{name}")]
        [Authorize(Roles = "Receptionist")]
        public async Task<IActionResult> UpdateGuest(string name, [FromBody] GuestDto guestDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var updatedGuest = await _guestService.UpdateGuestAsync(name, guestDto);
                return Ok(updatedGuest);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { Message = "Internal Server Error", Details = ex.Message });
            }
        }

        // GET: api/guests/{name}
        [HttpGet("{name}")]
        [Authorize(Roles = "Receptionist")]
        public async Task<IActionResult> GetGuestByName(string name)
        {
            var guest = await _guestService.GetGuestByNameAsync(name);
            if (guest == null)
                return NotFound();

            return Ok(guest);
        }
    }
}
