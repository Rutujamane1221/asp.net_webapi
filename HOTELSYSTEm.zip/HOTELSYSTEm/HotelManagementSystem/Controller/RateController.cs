using Microsoft.AspNetCore.Mvc;
using HotelManagementSystem.Models;
using HotelManagementSystem.Services;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace HotelManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RatesController : ControllerBase
    {
        private readonly IRateService _rateService;

        public RatesController(IRateService rateService)
        {
            _rateService = rateService;
        }

        // POST: api/rates
        [HttpPost]
        [Authorize(Roles = "Owner")]

        public async Task<IActionResult> SetRate([FromBody] RateDto rateDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var rate = await _rateService.AddRateAsync(rateDto);
                return CreatedAtAction(nameof(GetRateById), new { rateId = rate.RateId }, rate);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { Message = ex.Message });
            }
        }

        // GET: api/rates/{id}
        [HttpGet("{id}")]
        [Authorize(Roles = "Owner")]

        public async Task<IActionResult> GetRateById(int id)
        {
            var rate = await _rateService.GetRateByIdAsync(id);

            if (rate == null)
            {
                return NotFound(new { Message = "Rate not found." });
            }

            return Ok(rate);
        }
    }
}
