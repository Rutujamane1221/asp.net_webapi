using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HotelManagementSystem.Models;

namespace HotelManagementSystem.Controllers
{
    public class HotelController : ControllerBase
    {
    public class UserService
   {
    private readonly HotelContext _context;

    // Constructor injection
    public UserService(HotelContext context)
    {
        _context = context;
    }

    public async Task<List<User>> GetAllUsersAsync()
    {
        return await _context.Users.ToListAsync();
    }
    

    }
    }
}
